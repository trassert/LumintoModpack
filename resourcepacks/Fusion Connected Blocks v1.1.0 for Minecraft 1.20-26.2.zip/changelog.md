### Fusion Connected Blocks 1.1.0
- Added connecting textures for Polished Deepslate, Polished Cinnabar, and Polished Sulfur
- Fixed top side of top slabs connecting to bottom slabs instead of top slabs

### Fusion Connected Blocks 1.0.2
- Account for 1.21.9 pack.mcmeta format changes

### Fusion Connected Blocks 1.0.1
- Fixed log spam on Minecraft versions with polished tuff

### Fusion Connected Blocks 1.0.0
- Initial release of Fusion Connected Blocks
